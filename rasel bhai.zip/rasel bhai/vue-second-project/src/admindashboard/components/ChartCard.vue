<template>
  <div class="card">
    <div class="header">
      <h3>CHART DATA</h3>
    </div>

    <img src="https://i.ibb.co/PYSz9bC/bar.png" class="chart-img" />

    <button class="btn">SEE MORE</button>
  </div>
</template>

<style scoped>
.card {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
}

.chart-img {
  width: 100%;
  margin: 10px 0;
}

.btn {
  background: #0a9be0;
  padding: 8px 15px;
  border: none;
  color: white;
  border-radius: 4px;
  float: right;
}
</style>
