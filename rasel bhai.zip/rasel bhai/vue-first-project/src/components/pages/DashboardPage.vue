<template>
  <div>
    <h2>Dashboard Page</h2>
    <p>Welcome to the dashboard!</p>
  </div>
</template>

<script>
export default {
  name: "DashboardPage",
};
</script>
